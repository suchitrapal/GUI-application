
package learning;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Resturant extends JFrame{
    JLabel Customer, Name, Contact, Food , Coffee, Type;
    JTextField tfNumber, tfName, tfContact;
    JButton reset, print, recepit;
    JComboBox cb1, cb2;
    JRadioButton r1, r2;
    JTextArea a1, a2;
    int total, coffeeprice, fprice;
    int ctotal, extra, nonextra;
          
    Resturant(){
        
          setTitle("Coffee Mug & Fun");  
          setSize(700, 500);
          setLayout(null);
          Customer= new JLabel("Customer No: ");
          Customer.setBounds(20, 50, 120, 30);
          
          Name= new JLabel("Customer Name: ");
          Name.setBounds(20, 100, 120, 30);
          
          Contact= new JLabel("Contact: ");
          Contact.setBounds(20, 150, 120, 30);
          
          Food= new JLabel("Food: ");
          Food.setBounds(20, 200, 120, 30);
          String[] food={"Pizza", "Burger", "Fries", "Pasta", "Macroni", "Peri Peri Maggie"};
          cb1= new JComboBox(food);
          cb1.setBounds(200, 200, 120, 30);
          
          Coffee= new JLabel("Coffee: ");
          Coffee.setBounds(20, 250, 120, 30);
          String[] coffee={"Cappuccion", "Espresso", "Late", "Caffe macchiato", "Americano", "Cafe Mocha", "Iced Coffee"};
          cb2= new JComboBox(coffee);
          cb2.setBounds(200, 250, 120, 30);
          r1= new JRadioButton("Normal Cheese");
          r2= new JRadioButton("Extra Cheese");
          r1.setBounds(200, 300, 150, 30);
          r2.setBounds(350, 300, 150, 30);
         
          Coffee= new JLabel("Coffee Type: ");
          Coffee.setBounds(20, 250, 120, 30);
          
          Type= new JLabel("Type: ");
          Type.setBounds(20, 300, 120, 30);
          
          a1= new JTextArea();
          a1.setBounds(520, 100, 260, 140);
          tfNumber= new JTextField();
          tfNumber.setBounds(150, 50, 200, 30);
          
          tfName= new JTextField();
          tfName.setBounds(150, 100, 200, 30);
          
          tfContact= new JTextField();
          tfContact.setBounds(150, 150, 200, 30);
          
       
          reset= new JButton("RESET");
          reset.setBounds(400, 100, 90,40);
          getContentPane().add(reset);
          
          print= new JButton("PRINT");
          print.setBounds(400, 150, 90,40);
          getContentPane().add(print);
          
          recepit= new JButton("RECEIPT");
          recepit.setBounds(400, 200, 90,40);
          getContentPane().add(recepit);
          
          //to choose one radio button
          ButtonGroup bg= new ButtonGroup();
          bg.add(r1);
          bg.add(r2);
          getContentPane().add(r1);
          getContentPane().add(r2);
          getContentPane().add(cb1);
          getContentPane().add(cb2);
          getContentPane().add(recepit);
          getContentPane().add(reset);
          getContentPane().add(print);
          getContentPane().add(Customer);
          getContentPane().add(tfNumber);
          getContentPane().add(a1);
          getContentPane().add(Name);
          getContentPane().add(tfName);
          getContentPane().add(Contact);
          getContentPane().add(tfContact);
          getContentPane().add(Food);
          getContentPane().add(Coffee);
          getContentPane().add(Type);
          
          //after clicking button (reset, recepit, print) it should show on text area
          reset.addActionListener(new ActionListener(){
              @Override
              public void actionPerformed(ActionEvent e) {
                 tfNumber.setText("");
                 tfContact.setText("");
                 tfName.setText("");
                 a1.setText("");
              }
          });
          
          //print method
          print.addActionListener(new ActionListener(){
              @Override
              public void actionPerformed(ActionEvent e) {
                  try {
                      a1.print();
                  } catch (PrinterException ex) {
                   System.out.println(ex.getMessage());
                  }
              }
          });
          
           recepit.addActionListener(new ActionListener(){
              @Override
              public void actionPerformed(ActionEvent e) {
                 a1.setText("Happy Coffeeing! Have fun please  ");
                 a1.setText(a1.getText() +"\nCustomer Number: "+ tfNumber.getText()+
                         "\nName: "+tfName.getText()+"\nContact: "+tfContact.getText());
                 a1.setText(a1.getText()+ "\nFood: "+cb1.getSelectedItem()
                 +"\nCoffee: "+ cb2.getSelectedItem());
                 if(cb1.getSelectedIndex()==0){
                    fprice=200; 
                 }
                 if(cb1.getSelectedIndex()==1){
                    fprice=150; 
                 }
                 if(cb1.getSelectedIndex()==2){
                    fprice=160; 
                 }
                 if(cb1.getSelectedIndex()==3){
                    fprice=180; 
                 }
                 if(cb1.getSelectedIndex()==4){
                    fprice=200; 
                 }
                 if(cb1.getSelectedIndex()==5){
                    fprice=170; 
                 }
                 if(cb2.getSelectedIndex()==0){
                    coffeeprice=150; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                  if(cb2.getSelectedIndex()==1){
                    coffeeprice=120; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                   if(cb2.getSelectedIndex()==2){
                    coffeeprice=140; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                    if(cb2.getSelectedIndex()==3){
                    coffeeprice=100; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                     if(cb2.getSelectedIndex()==4){
                    coffeeprice=160; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                      if(cb2.getSelectedIndex()==5){
                    coffeeprice=150; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
                 if(cb2.getSelectedIndex()==6){
                    coffeeprice=170; 
                    total=fprice+coffeeprice;
                    a1.setText(a1.getText()+"\nTotal Cost: "+total);
                 }
              }
          });
           
          setVisible(true);
          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          
    }
    public static void main(String[] args){
       Resturant res=new Resturant();
    }
}
